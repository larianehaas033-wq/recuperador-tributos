"""Importação de arquivos para o banco: SPED (EFD-Contribuições e EFD ICMS/IPI) e XMLs."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Callable

from . import db
from .parsers.efd import parse_efd
from .parsers.nfe_xml import iter_xml_sources, parse_nfe_bytes
from .parsers.sped_common import identificar_tipo, sha256_file

ITEM_COLS = [
    "nota_id", "empresa_id", "arquivo_id", "origem", "periodo", "data", "chave", "num_doc", "ind_oper", "cnpj_part",
    "num_item", "cod_item", "descricao", "ncm", "cfop", "unidade", "qtd", "vl_item", "vl_desc", "cst_icms",
    "vl_bc_icms", "aliq_icms", "vl_icms", "vl_bc_icms_st", "vl_icms_st", "vl_ipi", "cst_pis", "vl_bc_pis",
    "aliq_pis", "vl_pis", "cst_cofins", "vl_bc_cofins", "aliq_cofins", "vl_cofins", "cst_ibscbs", "cclasstrib",
]
NOTA_COLS = [
    "empresa_id", "arquivo_id", "origem", "chave", "modelo", "serie", "numero", "data", "periodo", "ind_oper",
    "ind_emit", "cnpj_emit", "cnpj_part", "crt_emit", "cod_sit", "cancelada", "vl_doc", "vl_icms", "vl_icms_st", "vl_pis",
    "vl_cofins", "fin_nfe", "chave_ref", "vl_cred_sn", "resumo_pis",
]

REGIME = {"1": "LUCRO_REAL", "2": "LUCRO_PRESUMIDO", "3": "MISTO"}

Progress = Callable[[str, float], None]


ANALITICO_COLS = ["cst_icms", "cfop", "aliq_icms", "vl_opr", "vl_bc_icms", "vl_icms", "vl_bc_icms_st", "vl_icms_st"]


def gravar_analitico(con, empresa_id: int, arquivo_id: int, nota_id: int, nota: dict) -> None:
    for a in nota.get("analitico") or []:
        con.execute(f"INSERT INTO analitico_icms (empresa_id, arquivo_id, nota_id, {','.join(ANALITICO_COLS)}) "
                    f"VALUES (?,?,?,{','.join('?' * len(ANALITICO_COLS))})",
                    [empresa_id, arquivo_id, nota_id] + [a.get(c) for c in ANALITICO_COLS])


def atualizar_regime(con, empresa_id: int) -> None:
    """Regime atual da empresa = o do período mais recente. Fonte: EFD-Contribuições (0110); sem ela, o CRT
    das notas que a própria empresa emitiu (1, 2 ou 4 = Simples Nacional)."""
    r = con.execute("SELECT regime FROM arquivos_sped WHERE empresa_id=? AND tipo='EFD_CONTRIB' AND regime IS NOT NULL"
                    " ORDER BY periodo_ini DESC LIMIT 1", (empresa_id,)).fetchone()
    regime = r["regime"] if r else None
    if not regime:
        m = con.execute("SELECT regime_manual FROM empresas WHERE id=?", (empresa_id,)).fetchone()
        regime = m["regime_manual"] if m else None
    if not regime:
        c = con.execute("SELECT crt_emit FROM notas_fiscais WHERE empresa_id=? AND origem='XML' AND ind_emit='0'"
                        " AND crt_emit IS NOT NULL ORDER BY data DESC LIMIT 1", (empresa_id,)).fetchone()
        if c:
            regime = "SIMPLES_NACIONAL" if c["crt_emit"] in ("1", "2", "4") else None
    if regime:
        con.execute("UPDATE empresas SET regime=? WHERE id=?", (regime, empresa_id))


def _upsert_empresa(con, cnpj: str, nome: str, uf: str, regime: str | None, ind_ativ: str | None) -> int:
    row = con.execute("SELECT id, regime, ind_ativ FROM empresas WHERE raiz_cnpj = ?", (cnpj[:8],)).fetchone()
    if row:
        if regime and not row["regime"]:
            con.execute("UPDATE empresas SET regime = ? WHERE id = ?", (regime, row["id"]))
        if ind_ativ and not row["ind_ativ"]:
            con.execute("UPDATE empresas SET ind_ativ = ? WHERE id = ?", (ind_ativ, row["id"]))
        return row["id"]
    cur = con.execute(
        "INSERT INTO empresas (cnpj, raiz_cnpj, nome, uf, regime, ind_ativ) VALUES (?,?,?,?,?,?)",
        (cnpj, cnpj[:8], nome, uf, regime, ind_ativ),
    )
    return cur.lastrowid


def gravar_produtos(con, empresa_id: int, produtos: dict) -> None:
    """Cadastro de produtos (registro 0200): tipo do item é a prova da destinação (revenda, insumo, uso e consumo)."""
    con.executemany(
        "INSERT INTO produtos (empresa_id, cod_item, descricao, ncm, tipo_item, unidade) VALUES (?,?,?,?,?,?) "
        "ON CONFLICT(empresa_id, cod_item) DO UPDATE SET descricao=excluded.descricao, ncm=excluded.ncm, "
        "tipo_item=COALESCE(NULLIF(excluded.tipo_item,''), produtos.tipo_item), unidade=excluded.unidade",
        [(empresa_id, k, v.get("descricao"), v.get("ncm"), v.get("tipo"), v.get("unidade")) for k, v in produtos.items()],
    )


def arquivo_assinado(path: Path) -> bool:
    """O PVA anexa a assinatura digital depois do |9999| (bloco que começa com SBRCAAEPDR). Só o arquivo
    transmitido a tem; o gerado pelo sistema da empresa ou do contador, antes de assinar, não."""
    with open(path, "rb") as f:
        f.seek(0, 2)
        tam = f.tell()
        f.seek(max(0, tam - 65536))
        fim = f.read()
    i = fim.rfind(b"|9999|")
    return i >= 0 and b"SBRCAAEPDR" in fim[i:]


def importar_sped(path: Path, progress: Progress | None = None) -> dict:
    tipo = identificar_tipo(path)
    if not tipo:
        return {"arquivo": path.name, "status": "IGNORADO", "motivo": "Não é um arquivo SPED reconhecido."}
    h = sha256_file(path)
    with db.tx() as con:
        if con.execute("SELECT 1 FROM arquivos_sped WHERE hash = ?", (h,)).fetchone():
            return {"arquivo": path.name, "status": "JA_IMPORTADO", "tipo": tipo}

    if progress:
        progress(f"Lendo {path.name}", 0.1)
    r = parse_efd(path, tipo)
    assinado = arquivo_assinado(path)
    if not r.cnpj:
        return {"arquivo": path.name, "status": "ERRO", "motivo": "Arquivo sem CNPJ no registro 0000."}

    with db.tx() as con:
        regime = REGIME.get(r.regime_pis_cofins) if tipo == "EFD_CONTRIB" else None
        empresa_id = _upsert_empresa(con, r.cnpj, r.nome, r.uf, regime,
                                     r.ind_ativ if tipo == "EFD_CONTRIB" else None)
        substituido = None
        antigo = con.execute(
            "SELECT id, nome, finalidade, assinado FROM arquivos_sped WHERE empresa_id=? AND tipo=? AND periodo_ini=?",
            (empresa_id, tipo, r.dt_ini),
        ).fetchone()
        if antigo:
            if antigo["finalidade"] == "retificadora" and r.finalidade == "original":
                return {"arquivo": path.name, "status": "IGNORADO",
                        "motivo": f"Já existe retificadora para {r.dt_ini[:7]} ({antigo['nome']})."}
            if antigo["assinado"] and not assinado:
                return {"arquivo": path.name, "status": "IGNORADO", "tipo": tipo,
                        "motivo": (f"Já existe o arquivo transmitido de {r.dt_ini[:7]} ({antigo['nome']}, com assinatura "
                                   "digital). Este não tem assinatura: é uma cópia não entregue (ex.: arquivo gerado "
                                   "pelo sistema da empresa) e não vale para o fisco. A análise usa o transmitido.")}
            con.execute("DELETE FROM arquivos_sped WHERE id = ?", (antigo["id"],))
            substituido = antigo["nome"]

        cur = con.execute(
            "INSERT INTO arquivos_sped (empresa_id, tipo, nome, caminho, hash, periodo_ini, periodo_fim, finalidade,"
            " regime, qtd_registros, assinado) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (empresa_id, tipo, path.name, str(path), h, r.dt_ini, r.dt_fin, r.finalidade, regime, r.registros,
             1 if assinado else 0),
        )
        atualizar_regime(con, empresa_id)
        con.execute("UPDATE analises SET desatualizada=1 WHERE empresa_id=?", (empresa_id,))
        arquivo_id = cur.lastrowid
        origem_doc = "SPED_CONTRIB" if tipo == "EFD_CONTRIB" else "SPED_ICMS"

        nota_ids: dict[int, int] = {}
        for n in r.notas:
            vals = dict(n, empresa_id=empresa_id, arquivo_id=arquivo_id, origem=origem_doc,
                        cnpj_emit=r.cnpj if n.get("ind_emit") == "0" else n.get("cnpj_part"),
                        resumo_pis=json.dumps(n["c175"]) if n.get("c175") else None)
            cur = con.execute(
                f"INSERT INTO notas_fiscais ({','.join(NOTA_COLS)}) VALUES ({','.join('?' * len(NOTA_COLS))})",
                [vals.get(c) for c in NOTA_COLS],
            )
            nota_ids[n["_idx"]] = cur.lastrowid
            gravar_analitico(con, empresa_id, arquivo_id, cur.lastrowid, n)

        gravar_produtos(con, empresa_id, r.produtos)
        batch = []
        for it in r.itens:
            vals = dict(it, nota_id=nota_ids.get(it.get("_nota")), empresa_id=empresa_id, arquivo_id=arquivo_id)
            batch.append([vals.get(c) for c in ITEM_COLS])
        con.executemany(
            f"INSERT INTO itens_nota ({','.join(ITEM_COLS)}) VALUES ({','.join('?' * len(ITEM_COLS))})", batch
        )
        for a in r.apuracoes:
            con.execute(
                "INSERT INTO apuracoes (empresa_id, arquivo_id, periodo, tributo, debitos, creditos, valor_recolher,"
                " saldo_credor) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(empresa_id, periodo, tributo) DO UPDATE SET"
                " arquivo_id=excluded.arquivo_id, debitos=excluded.debitos, creditos=excluded.creditos,"
                " valor_recolher=excluded.valor_recolher, saldo_credor=excluded.saldo_credor",
                (empresa_id, arquivo_id, a["periodo"], a["tributo"], a["debitos"], a["creditos"],
                 a["valor_recolher"], a["saldo_credor"]),
            )

    return {
        "arquivo": path.name, "status": "IMPORTADO", "tipo": tipo, "empresa_id": empresa_id, "cnpj": r.cnpj,
        "nome": r.nome, "periodo": (r.dt_ini or "")[:7], "finalidade": r.finalidade, "notas": len(r.notas),
        "itens": len(r.itens), "substituiu": substituido, "assinado": assinado,
        "avisos": r.avisos + ([] if assinado else [
            "Arquivo sem assinatura digital: não é o arquivo transmitido ao fisco. Se houver o transmitido "
            "(baixado do PVA/ReceitaNet), importe-o: ele substitui este e é o que o fisco cruza."]),
    }


def _cnpjs_da_nota(n: dict) -> set[str]:
    r = set()
    if len(n["cnpj_emit"]) == 14:
        r.add(n["cnpj_emit"][:8])
    if len(n["cnpj_dest"]) == 14 and not n["dest_cpf"]:
        r.add(n["cnpj_dest"][:8])
    return r


def _criar_empresas_dos_xmls(con, notas: list[dict], empresas: dict[str, int]) -> list[str]:
    """Quem importa só XMLs (sem SPED) também precisa ver a empresa. A empresa do lote é o CNPJ que aparece
    (como emitente ou destinatário) na maior parte das notas que ainda não são de nenhuma empresa cadastrada:
    nas vendas ela é a emitente, nas compras a destinatária; um fornecedor aparece só nas notas dele.
    Repete enquanto sobrar uma raiz presente em pelo menos 30% das notas restantes (lote com várias empresas)."""
    criadas = []
    restantes = [n for n in notas if not (_cnpjs_da_nota(n) & empresas.keys())]
    while restantes:
        conta = Counter(r for n in restantes for r in _cnpjs_da_nota(n))
        if not conta:
            break
        raiz, qtd = conta.most_common(1)[0]
        if qtd < max(1, 0.3 * len(restantes)):
            break
        dados = Counter()
        for n in restantes:
            if n["cnpj_emit"][:8] == raiz:
                dados[(n["cnpj_emit"], n.get("nome_emit") or "", n.get("uf_emit") or "")] += 1
            elif n["cnpj_dest"][:8] == raiz and not n["dest_cpf"]:
                dados[(n["cnpj_dest"], n.get("nome_dest") or "", n.get("uf_dest") or "")] += 1
        cnpj, nome, uf = dados.most_common(1)[0][0]
        nome = nome or next((k[1] for k, _ in dados.most_common() if k[1]), "") or f"Empresa {cnpj}"
        empresas[raiz] = _upsert_empresa(con, cnpj, nome, uf, None, None)
        criadas.append(nome)
        restantes = [n for n in restantes if raiz not in _cnpjs_da_nota(n)]
    return criadas


def importar_xmls(paths: list[Path], progress: Progress | None = None, notas_extra: list | None = None,
                  rotulo: str = "XMLs") -> dict:
    """Importa XMLs (arquivos, pastas, zip). Cada nota vai para a empresa cujo CNPJ (raiz) é emitente
    ou destinatário. Notas repetidas (mesma chave) são ignoradas. notas_extra: notas já lidas de outra fonte
    com a mesma estrutura (planilha de itens do DF-e)."""
    notas, cancel = list(notas_extra or []), set()
    for i, (nome, data) in enumerate(iter_xml_sources(paths)):
        n = parse_nfe_bytes(data, nome)
        if not n:
            continue
        if n["tipo"] == "CANCELAMENTO":
            cancel.add(n["chave"])
        else:
            notas.append(n)
        if progress and i % 500 == 0:
            progress(f"Lendo XMLs ({i})", 0.2)

    resumo = {"arquivo": rotulo, "status": "IMPORTADO", "tipo": "XML_NFE", "lidas": len(notas),
              "canceladas": len(cancel), "importadas": 0, "repetidas": 0, "sem_empresa": 0, "empresas": []}
    if not notas and not cancel:
        resumo["status"] = "IGNORADO"
        resumo["motivo"] = "Nenhum XML de NF-e/NFC-e válido encontrado."
        return resumo

    with db.tx() as con:
        empresas = {r["raiz_cnpj"]: r["id"] for r in con.execute("SELECT id, raiz_cnpj FROM empresas")}
        resumo["criadas"] = _criar_empresas_dos_xmls(con, notas, empresas)
        existentes = {r["chave"] for r in con.execute("SELECT chave FROM notas_fiscais WHERE origem='XML'")}
        h = hashlib.sha256("|".join(sorted(n["chave"] for n in notas)).encode()).hexdigest()
        # XMLs importados antes da 1.4.14 não guardaram finalidade, nota referenciada e crédito do Simples
        resumo["completadas"] = 0
        for n in notas:
            c = con.execute("UPDATE notas_fiscais SET fin_nfe=?, chave_ref=?, vl_cred_sn=?, crt_emit=coalesce(crt_emit, ?)"
                            " WHERE chave=? AND origem='XML' AND fin_nfe IS NULL",
                            (n.get("fin_nfe"), n.get("chave_ref"), n.get("vl_cred_sn"), n.get("crt_emit"), n["chave"]))
            resumo["completadas"] += c.rowcount
        if con.execute("SELECT 1 FROM arquivos_sped WHERE hash=?", (h,)).fetchone() and not cancel:
            resumo["status"] = "JA_IMPORTADO"
            return resumo
        arquivos: dict[int, int] = {}
        itens_batch = []
        for n in notas:
            emp_emit = empresas.get(n["cnpj_emit"][:8])
            emp_dest = empresas.get(n["cnpj_dest"][:8]) if not n["dest_cpf"] else None
            empresa_id = emp_emit or emp_dest
            if not empresa_id:
                resumo["sem_empresa"] += 1
                continue
            if n["chave"] in existentes:
                resumo["repetidas"] += 1
                continue
            existentes.add(n["chave"])
            if empresa_id not in arquivos:
                cur = con.execute(
                    "INSERT INTO arquivos_sped (empresa_id, tipo, nome, caminho, hash, finalidade) VALUES"
                    " (?,?,?,?,?,?)",
                    (empresa_id, "XML_NFE", "Lote de XMLs", ";".join(str(p) for p in paths)[:500],
                     f"{h}-{empresa_id}", "original"),
                )
                arquivos[empresa_id] = cur.lastrowid
            # ponto de vista da empresa: emitente com tpNF=1 é saída; destinatário é entrada
            if emp_emit == empresa_id:
                ind_oper = "1" if n["tp_nf"] == "1" else "0"
                ind_emit, part = "0", n["cnpj_dest"]
            else:
                ind_oper, ind_emit, part = "0", "1", n["cnpj_emit"]
            cancelada = 1 if (n["chave"] in cancel or not n["autorizada"]) else 0
            vals = dict(
                empresa_id=empresa_id, arquivo_id=arquivos[empresa_id], origem="XML", chave=n["chave"],
                modelo=n["modelo"], serie=n["serie"], numero=n["numero"], data=n["data"], periodo=n["periodo"],
                ind_oper=ind_oper, ind_emit=ind_emit, cnpj_emit=n["cnpj_emit"], cnpj_part=part, cod_sit=n["cstat"],
                crt_emit=n.get("crt_emit"),
                fin_nfe=n.get("fin_nfe"), chave_ref=n.get("chave_ref"), vl_cred_sn=n.get("vl_cred_sn"),
                cancelada=cancelada, vl_doc=n["vl_doc"], vl_icms=n["vl_icms"], vl_icms_st=n["vl_icms_st"],
                vl_pis=n["vl_pis"], vl_cofins=n["vl_cofins"],
            )
            cur = con.execute(
                f"INSERT INTO notas_fiscais ({','.join(NOTA_COLS)}) VALUES ({','.join('?' * len(NOTA_COLS))})",
                [vals.get(c) for c in NOTA_COLS],
            )
            nota_id = cur.lastrowid
            resumo["importadas"] += 1
            for it in n["itens"]:
                v = dict(it, nota_id=nota_id, empresa_id=empresa_id, arquivo_id=arquivos[empresa_id], origem="XML",
                         periodo=n["periodo"], data=n["data"], chave=n["chave"], num_doc=n["numero"],
                         ind_oper=ind_oper, cnpj_part=part)
                itens_batch.append([v.get(c) for c in ITEM_COLS])
        if itens_batch:
            con.executemany(
                f"INSERT INTO itens_nota ({','.join(ITEM_COLS)}) VALUES ({','.join('?' * len(ITEM_COLS))})",
                itens_batch,
            )
        if cancel:
            con.executemany("UPDATE notas_fiscais SET cancelada=1 WHERE chave=? AND origem='XML'",
                            [(c,) for c in cancel])
        resumo["empresas"] = list(arquivos.keys())
        if resumo["sem_empresa"]:
            resumo["motivo"] = (f"{resumo['sem_empresa']} notas não são de nenhuma empresa cadastrada "
                                "(nem emitente nem destinatário) e ficaram de fora.")
        for eid in arquivos:
            atualizar_regime(con, eid)
            con.execute("UPDATE analises SET desatualizada=1 WHERE empresa_id=?", (eid,))
    return resumo


def importar(paths: list[Path], progress: Progress | None = None) -> list[dict]:
    """Ponto de entrada: separa SPED e XML. SPED primeiro, para as empresas existirem quando os XMLs chegarem."""
    from .parsers.dfe_excel import eh_planilha_dfe, eh_planilha_dfe_notas, ler_planilha_dfe
    sped, xml, planilhas = [], [], []
    resultados = []
    for p in paths:
        if p.is_dir():
            sped += [s for s in p.rglob("*.txt") if s.is_file()]
            if any(True for _ in p.rglob("*.xml")) or any(True for _ in p.rglob("*.zip")):
                xml.append(p)
            planilhas += [x for x in p.rglob("*.xlsx") if x.is_file()]
        elif p.suffix.lower() in (".xml", ".zip"):
            xml.append(p)
        elif p.suffix.lower() in (".xlsx", ".xlsm"):
            planilhas.append(p)
        else:
            sped.append(p)
    for p in planilhas:
        if eh_planilha_dfe(p):
            try:
                resultados.append(importar_xmls([], notas_extra=ler_planilha_dfe(p), rotulo=p.name))
                resultados[-1]["tipo_fonte"] = "Planilha de itens do DF-e"
            except Exception as e:  # noqa: BLE001
                resultados.append({"arquivo": p.name, "status": "ERRO", "motivo": str(e)})
        elif eh_planilha_dfe_notas(p):
            resultados.append({"arquivo": p.name, "status": "IGNORADO",
                               "motivo": "Esta é a planilha só de notas. Use a planilha de ITENS das notas do DF-e "
                                         "(o crédito de ICMS depende do CST de cada produto)."})
        else:
            resultados.append({"arquivo": p.name, "status": "IGNORADO",
                               "motivo": "Planilha não reconhecida (aceita a planilha de itens das NF-e do DF-e/SAT)."})
    total = len(sped) + (1 if xml else 0)
    for i, p in enumerate(sorted(sped)):
        if progress:
            progress(f"Importando {p.name}", i / max(total, 1))
        try:
            resultados.append(importar_sped(p, progress=None))
        except Exception as e:  # um arquivo ruim não derruba o lote
            resultados.append({"arquivo": p.name, "status": "ERRO", "motivo": str(e)})
    if xml:
        if progress:
            progress("Importando XMLs", len(sped) / max(total, 1))
        try:
            resultados.append(importar_xmls(xml, progress=progress))
        except Exception as e:
            resultados.append({"arquivo": "XMLs", "status": "ERRO", "motivo": str(e)})
    _anexar_malha(resultados)
    return resultados


def _anexar_malha(resultados: list[dict]) -> None:
    """Ao subir EFD ICMS/IPI ou EFD-Contribuições, confere na hora os cruzamentos que podem levar o cliente à malha."""
    from .engine import malha
    from .rules.loader import carregar
    empresas = {r["empresa_id"] for r in resultados if r.get("status") == "IMPORTADO" and r.get("empresa_id")
                and r.get("tipo") in ("EFD_ICMS_IPI", "EFD_CONTRIB")}
    for r in resultados:  # XMLs novos também mudam o cruzamento de quem já tem EFD
        if r.get("tipo") == "XML_NFE" and r.get("status") == "IMPORTADO":
            empresas |= set(r.get("empresas") or [])
    if not empresas:
        return
    try:
        regras = carregar()
    except Exception:  # noqa: BLE001
        regras = None
    with db.tx() as con:
        for eid in empresas:
            if not con.execute("SELECT 1 FROM arquivos_sped WHERE empresa_id=? AND tipo IN ('EFD_ICMS_IPI','EFD_CONTRIB')",
                               (eid,)).fetchone():
                continue
            try:
                al = malha.verificar(con, eid, regras)
            except Exception as e:  # noqa: BLE001 — o alerta nunca derruba a importação
                al, erro = [], str(e)
            else:
                erro = None
            nome = con.execute("SELECT nome FROM empresas WHERE id=?", (eid,)).fetchone()
            item = dict(empresa_id=eid, nome=nome["nome"] if nome else "", **malha.resumo(al),
                        principais=al[:8], erro=erro)
            for r in resultados:
                if r.get("empresa_id") == eid or eid in (r.get("empresas") or []):
                    r["malha"] = item
